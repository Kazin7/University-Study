library(data.table)
library(tidyverse)
library(corrplot)

DF <- fread('News_Final.csv') %>% as_tibble()

str(DF)
DF_ex <- DF[DF$Topic=="microsoft",]

DF_new <- DF_ex[,c(7:11)]

sum(is.na(DF_new$SentimentTitle))
sum(is.na(DF_new$SentimentHeadline))
sum(is.na(DF_new$Facebook))
sum(is.na(DF_new$GooglePlus))
sum(is.na(DF_new$LinkedIn))

DF_new <- na.omit(DF_new)

sum(is.na(DF_new$Facebook))
sum(is.na(DF_new$GooglePlus))
sum(is.na(DF_new$LinkedIn))

DF_cor <- cor(DF_new)
corrplot(DF_cor , method ="circle")

cov(DF_new)
cor(DF_new)

pairs(DF_new)
