library(data.table)
library(tidyverse)
library(corrplot)

DF <- fread('News_Final.csv') %>% as_tibble()

str(DF)
DF_ex <- DF[DF$Topic=="microsoft",]

DF_a <- DF_ex[,c(6)]
DF_b <- DF_ex[,c(9:11)]

str(DF_a)
str(DF_b)

DF_new <- cbind(DF_a , DF_b)

sum(is.na(DF_new$Facebook))
sum(is.na(DF_new$GooglePlus))
sum(is.na(DF_new$LinkedIn))

DF_new <- na.omit(DF_new)

sum(is.na(DF_new$Facebook))
sum(is.na(DF_new$GooglePlus))
sum(is.na(DF_new$LinkedIn))

ggplot(DF_new) + geom_bar(stat="identity",aes(x = PublishDate,y = Facebook ,fill="Facebook"))+ geom_bar(stat="identity",aes(x = PublishDate,y = GooglePlus ,fill="GooglePlus"))+geom_bar(stat="identity",aes(x = PublishDate,y = LinkedIn ,fill="LinkedIn"))
