library(data.table)
library(tidyverse)
library(caret)

DF <- fread('Regular_Season_Batter.csv ') %>% as_tibble()

input <- DF %>% na.omit() %>% select(-'height/weight',-year_born,-position,-career,-starting_salary)
input <- input %>% mutate(H = H-`2B`-`3B`- HR)
LG <- input[input$team=="LG",]

indexTrain <- createDataPartition(LG$team , p = .7, list = F)
training <- LG[indexTrain, ]
testing <- LG[-indexTrain, ]

train <- lm(G~H+`2B`+`3B`+HR,data = training)
train
summary(train)

testing
predict(train,testing)
