library(data.table)
library(tidyverse)
library(caret)

DF <- fread('Stroke Prediction Dataset.csv') %>% as_tibble()
input <- DF[!DF$bmi == 'N/A',]
input$bmi <- as.integer(input$bmi)

str0 <- input[input$stroke == 0,]
str1 <- input[input$stroke == 1,]

rand <- input[sample(nrow(str0),209),]

str <- rbind(rand,str1)

indexTrain <- createDataPartition(str$bmi , p = .7, list = F)
training <- str[indexTrain, ]
testing <- str[-indexTrain, ]

train <- glm(stroke~.,data = training)
train
summary(train)

st <- step(train,direction = "backward")
summary(st)

predict(st,testing)
