﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApp2
{
    public partial class InputForm : Form
    {
        public InputForm()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string name;//변수 생성
            int age;
            string gender;
            int year;
            int month;
            int day;
            string favorite = "";

            name = txtName.Text;//텍스트에 입력받은 값들로 변수에 값 저장
            age = int.Parse(txtAge.Text);

            if (rdoMan.Checked)
            {
                gender = "man";
            }
            else
            {
                gender = "woman";
            }

            year = int.Parse(txtYear.Text);
            month = int.Parse(txtMonth.Text);
            day = int.Parse(txtDay.Text);

            if (cbFishing.Checked)//체크되었을 경우는 따로 한줄씩 저장
            {
                favorite += "fishing" +Environment.NewLine;
            }
           if (cbGaming.Checked)
            {
                favorite += "gaming" + Environment.NewLine;
            }
            if (cbSinging.Checked)
            {
                favorite += "singing" + Environment.NewLine;
            }
            Info info = new Info(name,age,gender,year,month,day,favorite);//값을 전달하여 객체를 생성

            ReceivedForm rf = new ReceivedForm(info);//객체를 기반한 전달 방법

            //ReceivedForm rf = new ReceivedForm(name,age,gender,year,month,day,favorite);//값을 기반한 전달 방법
            rf.Show();
        }
    }
}
