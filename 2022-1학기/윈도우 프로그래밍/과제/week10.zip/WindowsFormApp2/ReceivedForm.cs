﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApp2
{
    public partial class ReceivedForm : Form
    {
        public ReceivedForm()
        {
            InitializeComponent();
        }
        public ReceivedForm(string name,int age , string gender , int year , int month , int day,string favorite)//값을 이용하여 창만들기
        {
            InitializeComponent();
            txtName.Text = name;
            txtAge.Text = age + "";
            txtGender.Text = gender;
            txtYear.Text = year + "";
            txtMonth.Text = month + "";
            txtDay.Text = day + "";
            txtFavorite.Text = favorite;
        }
        public ReceivedForm(Info info)//객체를 이용하여 창만들기
        {
            InitializeComponent();
            txtName.Text = info.Name;
            txtAge.Text = info.Age + "";
            txtGender.Text = info.Gender;
            txtYear.Text = info.Year + "";
            txtMonth.Text = info.Month + "";
            txtDay.Text = info.Day + "";
            txtFavorite.Text = info.Favorite;

        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
