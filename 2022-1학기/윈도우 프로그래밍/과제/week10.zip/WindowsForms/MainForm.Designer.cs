﻿namespace WindowsForms
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblFormBorder = new System.Windows.Forms.Label();
            this.lblOpacity = new System.Windows.Forms.Label();
            this.lblSize = new System.Windows.Forms.Label();
            this.lblWidth = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtX = new System.Windows.Forms.TextBox();
            this.txtY = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtOpacity = new System.Windows.Forms.TextBox();
            this.btnCreateForm = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdoNone = new System.Windows.Forms.RadioButton();
            this.rdoSingle = new System.Windows.Forms.RadioButton();
            this.rdoWindow = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(58, 44);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(72, 12);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "window title";
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Location = new System.Drawing.Point(58, 116);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(97, 12);
            this.lblLocation.TabIndex = 0;
            this.lblLocation.Text = "window location";
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(192, 95);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(12, 12);
            this.lblX.TabIndex = 0;
            this.lblX.Text = "x";
            // 
            // lblY
            // 
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(258, 95);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(12, 12);
            this.lblY.TabIndex = 0;
            this.lblY.Text = "y";
            // 
            // lblFormBorder
            // 
            this.lblFormBorder.AutoSize = true;
            this.lblFormBorder.Location = new System.Drawing.Point(58, 188);
            this.lblFormBorder.Name = "lblFormBorder";
            this.lblFormBorder.Size = new System.Drawing.Size(99, 12);
            this.lblFormBorder.TabIndex = 0;
            this.lblFormBorder.Text = "FormBorderStyle";
            // 
            // lblOpacity
            // 
            this.lblOpacity.AutoSize = true;
            this.lblOpacity.Location = new System.Drawing.Point(58, 254);
            this.lblOpacity.Name = "lblOpacity";
            this.lblOpacity.Size = new System.Drawing.Size(48, 12);
            this.lblOpacity.TabIndex = 0;
            this.lblOpacity.Text = "Opacity";
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(320, 116);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(77, 12);
            this.lblSize.TabIndex = 0;
            this.lblSize.Text = "window size";
            // 
            // lblWidth
            // 
            this.lblWidth.AutoSize = true;
            this.lblWidth.Location = new System.Drawing.Point(454, 95);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(35, 12);
            this.lblWidth.TabIndex = 0;
            this.lblWidth.Text = "width";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(541, 95);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(39, 12);
            this.lblHeight.TabIndex = 0;
            this.lblHeight.Text = "height";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(145, 41);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(363, 21);
            this.txtTitle.TabIndex = 1;
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(170, 116);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(55, 21);
            this.txtX.TabIndex = 2;
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(242, 116);
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(55, 21);
            this.txtY.TabIndex = 2;
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(453, 116);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(55, 21);
            this.txtWidth.TabIndex = 2;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(525, 116);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(55, 21);
            this.txtHeight.TabIndex = 2;
            // 
            // txtOpacity
            // 
            this.txtOpacity.Location = new System.Drawing.Point(133, 251);
            this.txtOpacity.Name = "txtOpacity";
            this.txtOpacity.Size = new System.Drawing.Size(110, 21);
            this.txtOpacity.TabIndex = 2;
            // 
            // btnCreateForm
            // 
            this.btnCreateForm.Location = new System.Drawing.Point(278, 331);
            this.btnCreateForm.Name = "btnCreateForm";
            this.btnCreateForm.Size = new System.Drawing.Size(211, 55);
            this.btnCreateForm.TabIndex = 3;
            this.btnCreateForm.Text = "Create Form";
            this.btnCreateForm.UseVisualStyleBackColor = true;
            this.btnCreateForm.Click += new System.EventHandler(this.btnCreateForm_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdoWindow);
            this.panel1.Controls.Add(this.rdoSingle);
            this.panel1.Controls.Add(this.rdoNone);
            this.panel1.Location = new System.Drawing.Point(163, 143);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(201, 100);
            this.panel1.TabIndex = 4;
            // 
            // rdoNone
            // 
            this.rdoNone.AutoSize = true;
            this.rdoNone.Location = new System.Drawing.Point(7, 13);
            this.rdoNone.Name = "rdoNone";
            this.rdoNone.Size = new System.Drawing.Size(53, 16);
            this.rdoNone.TabIndex = 0;
            this.rdoNone.TabStop = true;
            this.rdoNone.Text = "None";
            this.rdoNone.UseVisualStyleBackColor = true;
            // 
            // rdoSingle
            // 
            this.rdoSingle.AutoSize = true;
            this.rdoSingle.Location = new System.Drawing.Point(7, 35);
            this.rdoSingle.Name = "rdoSingle";
            this.rdoSingle.Size = new System.Drawing.Size(89, 16);
            this.rdoSingle.TabIndex = 0;
            this.rdoSingle.TabStop = true;
            this.rdoSingle.Text = "FixedSingle";
            this.rdoSingle.UseVisualStyleBackColor = true;
            // 
            // rdoWindow
            // 
            this.rdoWindow.AutoSize = true;
            this.rdoWindow.Location = new System.Drawing.Point(7, 57);
            this.rdoWindow.Name = "rdoWindow";
            this.rdoWindow.Size = new System.Drawing.Size(123, 16);
            this.rdoWindow.TabIndex = 0;
            this.rdoWindow.TabStop = true;
            this.rdoWindow.Text = "FixedToolWindow";
            this.rdoWindow.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCreateForm);
            this.Controls.Add(this.txtHeight);
            this.Controls.Add(this.txtY);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.txtOpacity);
            this.Controls.Add(this.txtX);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.lblOpacity);
            this.Controls.Add(this.lblSize);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblFormBorder);
            this.Controls.Add(this.lblWidth);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.lblTitle);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Label lblFormBorder;
        private System.Windows.Forms.Label lblOpacity;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.TextBox txtY;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtOpacity;
        private System.Windows.Forms.Button btnCreateForm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdoWindow;
        private System.Windows.Forms.RadioButton rdoSingle;
        private System.Windows.Forms.RadioButton rdoNone;
    }
}

