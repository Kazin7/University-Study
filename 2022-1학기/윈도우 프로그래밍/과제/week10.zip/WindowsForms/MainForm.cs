﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnCreateForm_Click(object sender, EventArgs e)
        {
            SubForm sf = new SubForm();//서브 폼을 생성하고
            sf.Text = txtTitle.Text;//타이틀을 받아서 설정한다
            sf.Location = new Point(int.Parse(txtX.Text), int.Parse(txtY.Text));//포인터를 이용하여 위치를 받아서 설정한다
            sf.Size = new Size(int.Parse(txtWidth.Text), int.Parse(txtHeight.Text));//사이즈를 이용하여 크기를 설정한다
            sf.Opacity = double.Parse(txtOpacity.Text);//투명도는 실수형으로 설정한다

            if(rdoNone.Checked)//라디오 버튼이 none일경우
                sf.FormBorderStyle = FormBorderStyle.None;
            else if (rdoSingle.Checked)//라디오 버튼이 FixedSingle일경우
                sf.FormBorderStyle = FormBorderStyle.FixedSingle;
            else//라디오 버튼이 FixedToolWindow일경우
                sf.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            sf.Show();
        }
    }
}
