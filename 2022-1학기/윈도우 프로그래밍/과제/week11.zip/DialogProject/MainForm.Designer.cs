﻿namespace DialogProject
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNormal = new System.Windows.Forms.Button();
            this.btnColorDialog = new System.Windows.Forms.Button();
            this.btnPrintDialog = new System.Windows.Forms.Button();
            this.btnOkCancel = new System.Windows.Forms.Button();
            this.btnFontDialog = new System.Windows.Forms.Button();
            this.btnUserDialog1 = new System.Windows.Forms.Button();
            this.btnYesNo = new System.Windows.Forms.Button();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.btnARI = new System.Windows.Forms.Button();
            this.btnFolder = new System.Windows.Forms.Button();
            this.btnUserDialog2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMain = new System.Windows.Forms.TextBox();
            this.txtParameter = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnNormal
            // 
            this.btnNormal.Location = new System.Drawing.Point(32, 71);
            this.btnNormal.Name = "btnNormal";
            this.btnNormal.Size = new System.Drawing.Size(127, 43);
            this.btnNormal.TabIndex = 0;
            this.btnNormal.Text = "기본 대화상자";
            this.btnNormal.UseVisualStyleBackColor = true;
            this.btnNormal.Click += new System.EventHandler(this.btnNormal_Click);
            // 
            // btnColorDialog
            // 
            this.btnColorDialog.Location = new System.Drawing.Point(165, 71);
            this.btnColorDialog.Name = "btnColorDialog";
            this.btnColorDialog.Size = new System.Drawing.Size(124, 43);
            this.btnColorDialog.TabIndex = 0;
            this.btnColorDialog.Text = "Color Dialog";
            this.btnColorDialog.UseVisualStyleBackColor = true;
            this.btnColorDialog.Click += new System.EventHandler(this.btnColorDialog_Click);
            // 
            // btnPrintDialog
            // 
            this.btnPrintDialog.Location = new System.Drawing.Point(295, 71);
            this.btnPrintDialog.Name = "btnPrintDialog";
            this.btnPrintDialog.Size = new System.Drawing.Size(124, 43);
            this.btnPrintDialog.TabIndex = 0;
            this.btnPrintDialog.Text = "Print Dialog";
            this.btnPrintDialog.UseVisualStyleBackColor = true;
            this.btnPrintDialog.Click += new System.EventHandler(this.btnPrintDialog_Click);
            // 
            // btnOkCancel
            // 
            this.btnOkCancel.Location = new System.Drawing.Point(32, 133);
            this.btnOkCancel.Name = "btnOkCancel";
            this.btnOkCancel.Size = new System.Drawing.Size(127, 43);
            this.btnOkCancel.TabIndex = 0;
            this.btnOkCancel.Text = "OK / CANCEL";
            this.btnOkCancel.UseVisualStyleBackColor = true;
            this.btnOkCancel.Click += new System.EventHandler(this.btnOkCancel_Click);
            // 
            // btnFontDialog
            // 
            this.btnFontDialog.Location = new System.Drawing.Point(165, 133);
            this.btnFontDialog.Name = "btnFontDialog";
            this.btnFontDialog.Size = new System.Drawing.Size(124, 43);
            this.btnFontDialog.TabIndex = 0;
            this.btnFontDialog.Text = "Font Dialog";
            this.btnFontDialog.UseVisualStyleBackColor = true;
            this.btnFontDialog.Click += new System.EventHandler(this.btnFontDialog_Click);
            // 
            // btnUserDialog1
            // 
            this.btnUserDialog1.Location = new System.Drawing.Point(295, 133);
            this.btnUserDialog1.Name = "btnUserDialog1";
            this.btnUserDialog1.Size = new System.Drawing.Size(124, 43);
            this.btnUserDialog1.TabIndex = 0;
            this.btnUserDialog1.Text = "사용자정의 1";
            this.btnUserDialog1.UseVisualStyleBackColor = true;
            this.btnUserDialog1.Click += new System.EventHandler(this.btnUserDialog1_Click);
            // 
            // btnYesNo
            // 
            this.btnYesNo.Location = new System.Drawing.Point(32, 197);
            this.btnYesNo.Name = "btnYesNo";
            this.btnYesNo.Size = new System.Drawing.Size(127, 43);
            this.btnYesNo.TabIndex = 0;
            this.btnYesNo.Text = "Yes / No";
            this.btnYesNo.UseVisualStyleBackColor = true;
            this.btnYesNo.Click += new System.EventHandler(this.btnYesNo_Click);
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Location = new System.Drawing.Point(165, 197);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(124, 43);
            this.btnOpenFile.TabIndex = 0;
            this.btnOpenFile.Text = "OpenFileDialog";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // btnARI
            // 
            this.btnARI.Location = new System.Drawing.Point(32, 263);
            this.btnARI.Name = "btnARI";
            this.btnARI.Size = new System.Drawing.Size(127, 43);
            this.btnARI.TabIndex = 0;
            this.btnARI.Text = "Abort/Retry/Ignore";
            this.btnARI.UseVisualStyleBackColor = true;
            this.btnARI.Click += new System.EventHandler(this.btnARI_Click);
            // 
            // btnFolder
            // 
            this.btnFolder.Location = new System.Drawing.Point(165, 263);
            this.btnFolder.Name = "btnFolder";
            this.btnFolder.Size = new System.Drawing.Size(124, 43);
            this.btnFolder.TabIndex = 0;
            this.btnFolder.Text = "FolderBrowser";
            this.btnFolder.UseVisualStyleBackColor = true;
            this.btnFolder.Click += new System.EventHandler(this.btnFolder_Click);
            // 
            // btnUserDialog2
            // 
            this.btnUserDialog2.Location = new System.Drawing.Point(295, 263);
            this.btnUserDialog2.Name = "btnUserDialog2";
            this.btnUserDialog2.Size = new System.Drawing.Size(124, 43);
            this.btnUserDialog2.TabIndex = 0;
            this.btnUserDialog2.Text = "사용자정의 2";
            this.btnUserDialog2.UseVisualStyleBackColor = true;
            this.btnUserDialog2.Click += new System.EventHandler(this.button12_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(302, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "parameter";
            // 
            // txtMain
            // 
            this.txtMain.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtMain.Location = new System.Drawing.Point(32, 13);
            this.txtMain.Multiline = true;
            this.txtMain.Name = "txtMain";
            this.txtMain.Size = new System.Drawing.Size(387, 52);
            this.txtMain.TabIndex = 2;
            this.txtMain.Text = "C# programing";
            // 
            // txtParameter
            // 
            this.txtParameter.Location = new System.Drawing.Point(295, 219);
            this.txtParameter.Name = "txtParameter";
            this.txtParameter.Size = new System.Drawing.Size(124, 21);
            this.txtParameter.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 335);
            this.Controls.Add(this.txtParameter);
            this.Controls.Add(this.txtMain);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUserDialog2);
            this.Controls.Add(this.btnUserDialog1);
            this.Controls.Add(this.btnPrintDialog);
            this.Controls.Add(this.btnFolder);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.btnFontDialog);
            this.Controls.Add(this.btnColorDialog);
            this.Controls.Add(this.btnARI);
            this.Controls.Add(this.btnYesNo);
            this.Controls.Add(this.btnOkCancel);
            this.Controls.Add(this.btnNormal);
            this.Name = "MainForm";
            this.Text = "대화상자";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNormal;
        private System.Windows.Forms.Button btnColorDialog;
        private System.Windows.Forms.Button btnPrintDialog;
        private System.Windows.Forms.Button btnOkCancel;
        private System.Windows.Forms.Button btnFontDialog;
        private System.Windows.Forms.Button btnUserDialog1;
        private System.Windows.Forms.Button btnYesNo;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.Button btnARI;
        private System.Windows.Forms.Button btnFolder;
        private System.Windows.Forms.Button btnUserDialog2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMain;
        private System.Windows.Forms.TextBox txtParameter;
    }
}

