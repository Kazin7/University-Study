﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialogProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button12_Click(object sender, EventArgs e)//사용자 정의1클릭시
        {
            UserDialog2Form uDialog2 = new UserDialog2Form();
            uDialog2.ShowDialog();

            txtParameter.Text = uDialog2.Parameter;
        }

        private void btnUserDialog1_Click(object sender, EventArgs e)//사용자 정의1클릭시
        {
            UserDialog1Form uDialog1 = new UserDialog1Form();
            uDialog1.Parameter = txtParameter.Text;

            uDialog1.Show();
        }

        private void btnNormal_Click(object sender, EventArgs e)//기본 대화상자 출력
        {
            MessageBox.Show("정보를 확인시켜주기 위한 대화상자","기본 대화상자",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void btnOkCancel_Click(object sender, EventArgs e)//ok cancel 대화상자
        {
            DialogResult dialogResult = MessageBox.Show("사용자로 부터 OK Cancel을 확인하기 위한 대화상자", "OK,Cancel 대화상자", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (dialogResult == DialogResult.OK)
            {
                txtMain.Text = "OK";
            }
            else
            {
                txtMain.Text = "Cancel";
            }
        }

        private void btnYesNo_Click(object sender, EventArgs e)//yes no cancel 대화상자
        {
            DialogResult dialogResult = MessageBox.Show("사용자로 부터 Yes , No , Cancel을 확인하기 위한 대화상자", "Yes , No , Cancel 대화상자", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                txtMain.Text = "Yes";
            }
            else if (dialogResult == DialogResult.No)
            {
                txtMain.Text = "No";
            }
            else
            {
                txtMain.Text = "Cancel";
            }
        }

        private void btnARI_Click(object sender, EventArgs e)//abort retry ignore 대화상자
        {
            DialogResult dialogResult = MessageBox.Show("사용자로 부터 Abort, Retry , Ignore를 결정하기 위한 대화상자", "Abort, Retry , Ignore 대화상자", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Stop);
            if (dialogResult == DialogResult.Abort)
            {
                txtMain.Text = "Abort";
            }
            else if (dialogResult == DialogResult.Retry)
            {
                txtMain.Text = "Retry";
            }
            else
            {
                txtMain.Text = "Ignore";
            }
        }

        private void btnColorDialog_Click(object sender, EventArgs e)//color dialog 버튼 클릭시
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();
            txtMain.BackColor = colorDialog.Color;
        }

        private void btnFontDialog_Click(object sender, EventArgs e)//font dialog 버튼 클릭시
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowDialog();
            txtMain.Font = fontDialog.Font;
        }

        private void btnOpenFile_Click(object sender, EventArgs e)//openFileDialog  버튼 클릭시
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Multiselect = false;
            openFileDialog1.ShowDialog();


            txtMain.Text = openFileDialog1.SafeFileName;//파일 이름만 텍스트에 출력
        }

        private void btnFolder_Click(object sender, EventArgs e)//FolderBrowser 클릭시
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.ShowDialog();

            txtMain.Text = folderBrowserDialog.SelectedPath;//경로를 텍스트에 출력
        }

        private void btnPrintDialog_Click(object sender, EventArgs e)//print dialog 버튼 클릭시
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.ShowDialog();

            txtMain.Text = printDialog.PrinterSettings.PrinterName;//프린터 이름을 텍스트에 출력
        }
    }
}
