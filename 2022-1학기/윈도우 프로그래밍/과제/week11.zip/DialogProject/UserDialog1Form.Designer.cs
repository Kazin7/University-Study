﻿namespace DialogProject
{
    partial class UserDialog1Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtParameter = new System.Windows.Forms.TextBox();
            this.lblParmeter = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtParameter
            // 
            this.txtParameter.Location = new System.Drawing.Point(204, 89);
            this.txtParameter.Name = "txtParameter";
            this.txtParameter.Size = new System.Drawing.Size(154, 21);
            this.txtParameter.TabIndex = 0;
            // 
            // lblParmeter
            // 
            this.lblParmeter.AutoSize = true;
            this.lblParmeter.Location = new System.Drawing.Point(109, 92);
            this.lblParmeter.Name = "lblParmeter";
            this.lblParmeter.Size = new System.Drawing.Size(73, 12);
            this.lblParmeter.TabIndex = 1;
            this.lblParmeter.Text = "전달 받은 값";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(184, 159);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "닫기";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // UserDialog1Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 239);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblParmeter);
            this.Controls.Add(this.txtParameter);
            this.Name = "UserDialog1Form";
            this.Text = "전달 받은 값을 나타내는 폼";
            this.Load += new System.EventHandler(this.UserDialog1Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtParameter;
        private System.Windows.Forms.Label lblParmeter;
        private System.Windows.Forms.Button btnClose;
    }
}