﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialogProject
{
    public partial class UserDialog1Form : Form
    {
        private string parameter;

        public string Parameter
        {
            get { return parameter; }
            set { this.parameter = value; }
        }
        public UserDialog1Form()
        {
            InitializeComponent();
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UserDialog1Form_Load(object sender, EventArgs e)
        {
            txtParameter.Text = parameter;
        }
    }
}
