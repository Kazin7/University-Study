﻿namespace DialogProject
{
    partial class UserDialog2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAccept = new System.Windows.Forms.Button();
            this.lblParmeter = new System.Windows.Forms.Label();
            this.txtParmeter = new System.Windows.Forms.TextBox();
            this.btnReject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAccept
            // 
            this.btnAccept.Location = new System.Drawing.Point(118, 158);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(124, 48);
            this.btnAccept.TabIndex = 5;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // lblParmeter
            // 
            this.lblParmeter.AutoSize = true;
            this.lblParmeter.Location = new System.Drawing.Point(116, 108);
            this.lblParmeter.Name = "lblParmeter";
            this.lblParmeter.Size = new System.Drawing.Size(94, 12);
            this.lblParmeter.TabIndex = 4;
            this.lblParmeter.Text = "input Parameter";
            // 
            // txtParmeter
            // 
            this.txtParmeter.Location = new System.Drawing.Point(226, 105);
            this.txtParmeter.Name = "txtParmeter";
            this.txtParmeter.Size = new System.Drawing.Size(154, 21);
            this.txtParmeter.TabIndex = 3;
            // 
            // btnReject
            // 
            this.btnReject.Location = new System.Drawing.Point(256, 158);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(124, 48);
            this.btnReject.TabIndex = 5;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = true;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // UserDialog2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 289);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.lblParmeter);
            this.Controls.Add(this.txtParmeter);
            this.Name = "UserDialog2Form";
            this.Text = "값을 입력받을 폼";
            this.Load += new System.EventHandler(this.UserDialog2Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label lblParmeter;
        private System.Windows.Forms.TextBox txtParmeter;
        private System.Windows.Forms.Button btnReject;
    }
}