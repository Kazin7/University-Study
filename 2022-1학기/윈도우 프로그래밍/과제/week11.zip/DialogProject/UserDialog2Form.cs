﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialogProject
{
    public partial class UserDialog2Form : Form
    {
        private string parameter;

        public string Parameter
        {
            get { return parameter; }
            set { this.parameter = value; }
        }
        public UserDialog2Form()
        {
            InitializeComponent();
        }

        private void UserDialog2Form_Load(object sender, EventArgs e)
        {

        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            parameter = txtParmeter.Text;
            Close();
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            parameter = "";
            Close();
        }
    }
}
