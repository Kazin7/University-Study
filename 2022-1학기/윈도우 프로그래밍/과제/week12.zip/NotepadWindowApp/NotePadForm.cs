﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotepadWindowApp
{
    public partial class NotePadForm : Form
    {
        public NotePadForm()
        {
            InitializeComponent();
        }

        private void mnuExit_Click(object sender, EventArgs e)//종료버튼 클릭시
        {
            this.Close();//종료
        }

        private void mnuNew_Click(object sender, EventArgs e)//새로운 파일 만들기
        {
            txtEdit.Text = "";//내용 초기화
        }

        private void mnuFont_Click(object sender, EventArgs e)//폰트 변경
        {
            if (fontDlg.ShowDialog() == DialogResult.OK)
                txtEdit.Font = fontDlg.Font;
        }

        private void mnuOpen_Click(object sender, EventArgs e)//오픈 클릭시
        {
            if (openDlg.ShowDialog() == DialogResult.OK)
                txtEdit.Text = "파일을 열었습니다.";
        }

        private void mnuSave_Click(object sender, EventArgs e)//저장 클릭시
        {
            if (saveDlg.ShowDialog() == DialogResult.OK)
                txtEdit.Text = "출력했습니다.";
        }

        private void mnuPrint_Click(object sender, EventArgs e)//프린트 클릭시
        {
            if (printDlg.ShowDialog() == DialogResult.OK)
                txtEdit.Text = "프린트합니다.";
        }
    }
}
