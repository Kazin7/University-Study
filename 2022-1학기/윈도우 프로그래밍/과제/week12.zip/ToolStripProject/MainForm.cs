﻿using System;
using System.Windows.Forms;

namespace ToolStripProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void mnuOpen_Click(object sender, EventArgs e)//파일 열기시
        {
            MessageBox.Show("파일열기메뉴선택", "ToolStripMenuItem_Click");
        }

        private void mnuSave_Click(object sender, EventArgs e)//파일 저장시
        {
            MessageBox.Show("파일저장메뉴선택", "ToolStripMenuItem_Click");
        }

        private void mnuExit_Click(object sender, EventArgs e)//종료시
        {
            this.Close();
        }


        private void mnuCenter_Click(object sender, EventArgs e)//center를 눌렀을경우
        {
            mnuLeft.Checked = false;//center를 제외한 나머지 false로 설정
            mnuCenter.Checked = true;
            mnuRight.Checked = false;

            txtEdit.TextAlign = HorizontalAlignment.Center;//가운데 정렬
        }

        private void mnuRight_Click(object sender, EventArgs e)//right를 눌렀을 경우
        {
            mnuLeft.Checked = false;//right를 제외한 나머지 false로 설정
            mnuCenter.Checked = false;
            mnuRight.Checked = true;

            txtEdit.TextAlign = HorizontalAlignment.Right;//오른쪽 정렬
        }

        private void mnuLeft_Click(object sender, EventArgs e)//왼쪽을 눌렀을 경우
        {
            mnuLeft.Checked = true;//left를 제외한 나머지 false로 설정
            mnuCenter.Checked = false;
            mnuRight.Checked = false;

            txtEdit.TextAlign = HorizontalAlignment.Left;//왼쪽 정렬
        }

        private void mnuAlign_Click(object sender, EventArgs e)//이렇게 메뉴 처리도 가능
        {
            ToolStripMenuItem item = (ToolStripMenuItem)sender;

            foreach (ToolStripMenuItem it in item.Owner.Items)
            {
                if (it == item)
                {
                    it.Checked = true;  // 클릭한 메뉴만 checked를  true로
                }
                else
                {
                    it.Checked = false;  // 나머지 메뉴는 false로 변경
                }
            }
        }

        private void mnuCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtEdit.Text);  //클립보드로 텍스트박스의 문자열 복사
        }

        private void mnuPaste_Click(object sender, EventArgs e)
        {
            txtEdit.Text += Clipboard.GetText();//클립보드의 텍스트를 가져와서 붙여넣기
        }

        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            statusStrip1.Items[0].Text = e.X + " . " + e.Y;//메인폼에서 마우스의 현재 위치 출력
        }

        private void txtEdit_MouseMove(object sender, MouseEventArgs e)
        {
            statusStrip1.Items[0].Text = e.X + " . " + e.Y;//텍스트에서 마우스의 현재 위치 출력
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)//툴스트립 라벨이 클릭시
        {
            MessageBox.Show(" statusStrip1_ItemClicked");//메세지 출력
        }
    }
}
