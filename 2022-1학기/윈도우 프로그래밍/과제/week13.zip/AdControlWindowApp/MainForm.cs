﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdControlWindowApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void nUpDown_ValueChanged(object sender, EventArgs e)
        {
            tbValue.Value = (int)nUpDown.Value;//서로의 값을 연동
            progress.Maximum = (int)nUpDown.Value;
        }

        private void tbValue_Scroll(object sender, EventArgs e)
        {
            nUpDown.Value = tbValue.Value;//서로의 값을 연동
            progress.Maximum = tbValue.Value;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progress.Value < progress.Maximum)//최댓값보다 작을 경우에만 값 증가
            {
                progress.Value += 10;
            }

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();//타이머 실행
        }
    }
}
