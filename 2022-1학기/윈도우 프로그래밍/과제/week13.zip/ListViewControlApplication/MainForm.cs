﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListViewControlApplication
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListViewItem.ListViewSubItem sub2 = new ListViewItem.ListViewSubItem();//리스트 뷰 서브 아이템 객체 만들기
            ListViewItem.ListViewSubItem sub3 = new ListViewItem.ListViewSubItem();
            ListViewItem.ListViewSubItem sub4 = new ListViewItem.ListViewSubItem();
            ListViewItem.ListViewSubItem sub5 = new ListViewItem.ListViewSubItem();
 
            sub2.Text = txtName.Text;//각각 값을 넣는다
            sub3.Text = txtAddress.Text;
            sub4.Text = txtTel.Text;
            sub5.Text = txtDept.Text;
           
            ListViewItem lvItem = new ListViewItem();//리스트뷰 아이템 객체 생성
            lvItem.Text = txtSno.Text;//첫번째 값은 리스트 뷰 객체의 텍스트로 넣음
            lvItem.SubItems.Add(sub2);//나머지 값 넣기
            lvItem.SubItems.Add(sub3);
            lvItem.SubItems.Add(sub4);
            lvItem.SubItems.Add(sub5);

            lstInfo.Items.Add(lvItem);//만든 객체를 리스트에 출력
        }

        private void btnRemove_Click(object sender, EventArgs e)//리스트 값 제거
        {
            if( lstInfo.SelectedItems.Count != 0)//선택되어있을 경우
            {
                lstInfo.SelectedItems[0].Remove();//선택된 아이템 삭제
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (lstInfo.SelectedItems.Count != 0)//선택되어있을 경우
            {
                txtSno.Text = lstInfo.SelectedItems[0].SubItems[0].Text;//선택된 값들을 텍스트에 출력
                txtName.Text = lstInfo.SelectedItems[0].SubItems[1].Text;
                txtAddress.Text = lstInfo.SelectedItems[0].SubItems[2].Text;
                txtTel.Text = lstInfo.SelectedItems[0].SubItems[3].Text;
                txtDept.Text = lstInfo.SelectedItems[0].SubItems[4].Text;
            }
        }

        private void dmView_SelectedItemChanged(object sender, EventArgs e)
        {
            if(dmView.Text == "Detail")//Detail Large small에 따른 아이콘 변경
            {
                lstInfo.View = View.Details;
            }
            else if(dmView.Text == "Large")
            {
                lstInfo.View = View.LargeIcon;
            }
            else
            {
                lstInfo.View = View.SmallIcon;
            }
        }
    }
}
