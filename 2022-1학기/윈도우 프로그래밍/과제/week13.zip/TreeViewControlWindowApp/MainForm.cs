﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TreeViewControlWindowApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnAddNode_Click(object sender, EventArgs e)
        {
            if(txtAddNode.Text != "")//값이 존재할경우 노드 추가
                tvCourse.SelectedNode.Nodes.Add(txtAddNode.Text, txtAddNode.Text);
            else
            {
                MessageBox.Show("입력된 노드명이 없음");
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            tvCourse.ExpandAll();//창이 로드 될때 트리뷰를 펼쳐서 출력
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lstCourse.Items.Add(tvCourse.SelectedNode.Text);//선택된 노드 값을 리스트에 출력
        }

        private void btnNodeRemove_Click(object sender, EventArgs e)
        {
            if( tvCourse.SelectedNode.Nodes.Count == 0)//자식 노드가 없을경우 삭제
            {
                tvCourse.Nodes.Remove(tvCourse.SelectedNode);
            }
            else
            {
                MessageBox.Show("자식 노드가 있는경우 삭제 불가");
            }
        }

        private void btnListRemove_Click(object sender, EventArgs e)
        {
            if(lstCourse.SelectedIndex != -1)//선택된 인덱스가 -1이 아닐경우 인덱스로 값을 찾아서 삭제
            {
                lstCourse.Items.RemoveAt(lstCourse.SelectedIndex);
            }
            else
            {
                MessageBox.Show("삭제할 아이템이 선택되지 않음");
            }
        }

        private void btnFindNode_Click(object sender, EventArgs e)
        {
            TreeNode SelectedNode = SearchNode(txtAddNode.Text, tvCourse.Nodes[0]);//값 찾기
            if (SelectedNode != null)
            {
                this.tvCourse.SelectedNode = SelectedNode;
                this.tvCourse.SelectedNode.Expand();
                this.tvCourse.Select();//포커스를 찾은 값에 둔다
            }
        }
        private TreeNode SearchNode(string SearchText, TreeNode StartNode)//노드를 찾는 함수
        {
            TreeNode node = null;
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    node = StartNode;
                    break;
                }
                if (StartNode.Nodes.Count != 0)
                {
                    node = SearchNode(SearchText, StartNode.Nodes[0]);//재귀 함수 자기자신을 호출
                    if (node != null)
                    {
                        break;
                    }
                }
                StartNode = StartNode.NextNode;
            }
            return node;
        }

    }
}
