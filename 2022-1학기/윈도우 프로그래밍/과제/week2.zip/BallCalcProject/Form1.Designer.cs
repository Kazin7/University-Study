﻿namespace BallCalcProject
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.txtVolume = new System.Windows.Forms.TextBox();
            this.txtApparent = new System.Windows.Forms.TextBox();
            this.btCalc = new System.Windows.Forms.Button();
            this.lblRadius = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.lblApparent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(248, 85);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(229, 21);
            this.txtRadius.TabIndex = 0;
            this.txtRadius.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtVolume
            // 
            this.txtVolume.Location = new System.Drawing.Point(248, 215);
            this.txtVolume.Name = "txtVolume";
            this.txtVolume.Size = new System.Drawing.Size(229, 21);
            this.txtVolume.TabIndex = 1;
            // 
            // txtApparent
            // 
            this.txtApparent.Location = new System.Drawing.Point(248, 275);
            this.txtApparent.Name = "txtApparent";
            this.txtApparent.Size = new System.Drawing.Size(229, 21);
            this.txtApparent.TabIndex = 2;
            // 
            // btCalc
            // 
            this.btCalc.Location = new System.Drawing.Point(324, 149);
            this.btCalc.Name = "btCalc";
            this.btCalc.Size = new System.Drawing.Size(75, 23);
            this.btCalc.TabIndex = 3;
            this.btCalc.Text = "Execute";
            this.btCalc.UseVisualStyleBackColor = true;
            this.btCalc.Click += new System.EventHandler(this.btCalc_Click);
            // 
            // lblRadius
            // 
            this.lblRadius.AutoSize = true;
            this.lblRadius.Location = new System.Drawing.Point(175, 88);
            this.lblRadius.Name = "lblRadius";
            this.lblRadius.Size = new System.Drawing.Size(53, 12);
            this.lblRadius.TabIndex = 4;
            this.lblRadius.Text = "반지름 R";
            this.lblRadius.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Location = new System.Drawing.Point(175, 218);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(29, 12);
            this.lblVolume.TabIndex = 5;
            this.lblVolume.Text = "부피";
            // 
            // lblApparent
            // 
            this.lblApparent.AutoSize = true;
            this.lblApparent.Location = new System.Drawing.Point(175, 284);
            this.lblApparent.Name = "lblApparent";
            this.lblApparent.Size = new System.Drawing.Size(41, 12);
            this.lblApparent.TabIndex = 6;
            this.lblApparent.Text = "표면적";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblApparent);
            this.Controls.Add(this.lblVolume);
            this.Controls.Add(this.lblRadius);
            this.Controls.Add(this.btCalc);
            this.Controls.Add(this.txtApparent);
            this.Controls.Add(this.txtVolume);
            this.Controls.Add(this.txtRadius);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.TextBox txtVolume;
        private System.Windows.Forms.TextBox txtApparent;
        private System.Windows.Forms.Button btCalc;
        private System.Windows.Forms.Label lblRadius;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblApparent;
    }
}

