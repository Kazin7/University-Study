﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BallCalcProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btCalc_Click(object sender, EventArgs e)
        {
            int r;
            double vol;
            double s;

            r = int.Parse(txtRadius.Text);
            vol = r * r * r * Math.PI * 4 / 3;
            s = 4 * r * r * Math.PI;

            txtVolume.Text = vol.ToString();
            txtApparent.Text = s.ToString();
        }
    }
}
