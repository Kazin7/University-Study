﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuGuDanProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btCalc_Click(object sender, EventArgs e)
        {
            int dan;
            String str = "";
            dan = int.Parse(txtDan.Text);
            
            for(int i = 2; i < 10; i++)
            {
                str += dan+"*"+i+"="+(dan*i) + (Environment.NewLine);

            }
            txtShow.Text = str;
        }
    }
}
