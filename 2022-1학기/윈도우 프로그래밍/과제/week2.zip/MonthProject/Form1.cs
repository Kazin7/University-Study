﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonthProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btCalc_Click(object sender, EventArgs e)
        {
            int month;
            month = int.Parse(txtMonth.Text);

            switch (month)
            {
                case 1:
                    txtDay.Text = 31.ToString();
                    break;
                case 2:
                    txtDay.Text = 28.ToString();
                    break;
                case 3:
                    txtDay.Text = 31.ToString();
                    break;
                case 4:
                    txtDay.Text = 30.ToString();
                    break;
                case 5:
                    txtDay.Text = 31.ToString();
                    break;
                case 6:
                    txtDay.Text = 30.ToString();
                    break;
                case 7:
                    txtDay.Text = 31.ToString();
                    break;
                case 8:
                    txtDay.Text = 31.ToString();
                    break;
                case 9:
                    txtDay.Text = 30.ToString();
                    break;
                case 10:
                    txtDay.Text = 31.ToString();
                    break;
                case 11:
                    txtDay.Text = 30.ToString();
                    break;
                case 12:
                    txtDay.Text = 31.ToString();
                    break;
                default:
                    txtDay.Text = "존재하지 않는 달입니다.";
                    break;
            }
        }
    }
}
