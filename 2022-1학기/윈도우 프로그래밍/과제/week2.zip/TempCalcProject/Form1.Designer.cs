﻿namespace TempCalcProject
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblC = new System.Windows.Forms.Label();
            this.lblF = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtF = new System.Windows.Forms.TextBox();
            this.btCalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(160, 98);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(29, 12);
            this.lblC.TabIndex = 0;
            this.lblC.Text = "섭씨";
            // 
            // lblF
            // 
            this.lblF.AutoSize = true;
            this.lblF.Location = new System.Drawing.Point(160, 235);
            this.lblF.Name = "lblF";
            this.lblF.Size = new System.Drawing.Size(29, 12);
            this.lblF.TabIndex = 1;
            this.lblF.Text = "화씨";
            this.lblF.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(264, 89);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 21);
            this.txtC.TabIndex = 2;
            // 
            // txtF
            // 
            this.txtF.Location = new System.Drawing.Point(264, 226);
            this.txtF.Name = "txtF";
            this.txtF.Size = new System.Drawing.Size(100, 21);
            this.txtF.TabIndex = 3;
            // 
            // btCalc
            // 
            this.btCalc.Location = new System.Drawing.Point(276, 159);
            this.btCalc.Name = "btCalc";
            this.btCalc.Size = new System.Drawing.Size(75, 23);
            this.btCalc.TabIndex = 4;
            this.btCalc.Text = "Execute";
            this.btCalc.UseVisualStyleBackColor = true;
            this.btCalc.Click += new System.EventHandler(this.btCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btCalc);
            this.Controls.Add(this.txtF);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.lblF);
            this.Controls.Add(this.lblC);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblF;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.Button btCalc;
    }
}

