﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FractionProject
{
    public partial class FractionAddForm : Form
    {
        public FractionAddForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            int numerator1, numerator2, numerator3 = 0;
            int denominator1, denominator2, denominator3 = 0;
            int small;

            numerator1 = int.Parse(txtNumerator1.Text);
            numerator2 = int.Parse(txtNumerator2.Text);
            denominator1 = int.Parse(txtDenominator1.Text);
            denominator2 = int.Parse(txtDenominator2.Text);

            if( denominator1 == denominator2)
            {
                denominator3 = denominator1;
                numerator3 = numerator1 + numerator2;
            }
            else//통분
            {
                denominator3 = denominator1 * denominator2;
                numerator3 = (numerator1 * denominator2) + (numerator2 * denominator1);
            }
            //약분
            if(numerator3 < denominator3)
            {
                small = numerator3;
            }
            else
            {
                small = denominator3;
            }
            for(int i = 2; i < small; i++)
            {
                if(numerator3%i == 0  && denominator3%i == 0)
                {
                    numerator3 = numerator3/i;
                    denominator3 = denominator3/i;
                }
            }
            txtDenominator3.Text = denominator3.ToString();
            txtNumerator3.Text = numerator3.ToString();
        }
    }
}
