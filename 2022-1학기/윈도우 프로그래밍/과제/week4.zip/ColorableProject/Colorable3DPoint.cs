﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColorableProject
{
    internal class Colorable3DPoint : Point
    {
        private int z;
        private string color;

        public Colorable3DPoint(int x,int y,int z,string color) : base(x,y)//Point클래스에서 파생된 파생클래스
        {
            this.z = z;//나머지 부분들 초기화
            this.color = color;
        }
        public void SetZ(int z)//get set메서드 생성
        {
            this.z=z;
        }
        public void SetColor(string color)
        {
            this.color=color;  
        }
        public int GetZ()
        {
            return this.z;
        }
        public string GetColor()
        {
            return this.color;
        }
        public void MoveTo(int x,int y,int z)//값 변경하는 매서드
        {
            MoveTo(x, y);//부모 메서드를 이용하여 처리
            this.z = z;
        }
        public void MoveBy(int x ,int y,int z)//값 이동하는 매서드
        {
            MoveBy(x, y);//부모 메서드를 이용하여 처리
            this.z = this.z + z;
        }
        public override string ToString()//오버라이드를 이용하여 값 출력
        {
            return base.ToString() + ", z : " + this.z + " , color : " + this.color;
        }
    }
}
