﻿namespace ColorableProject
{
    partial class ColorableForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblNow = new System.Windows.Forms.Label();
            this.lblX1 = new System.Windows.Forms.Label();
            this.lblY1 = new System.Windows.Forms.Label();
            this.lblZ1 = new System.Windows.Forms.Label();
            this.lblC1 = new System.Windows.Forms.Label();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtZ1 = new System.Windows.Forms.TextBox();
            this.txtC1 = new System.Windows.Forms.TextBox();
            this.txtC2 = new System.Windows.Forms.TextBox();
            this.txtZ2 = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.lblC2 = new System.Windows.Forms.Label();
            this.lblZ2 = new System.Windows.Forms.Label();
            this.lblY2 = new System.Windows.Forms.Label();
            this.lblX2 = new System.Windows.Forms.Label();
            this.btnCal1 = new System.Windows.Forms.Button();
            this.btnMake = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnCal2 = new System.Windows.Forms.Button();
            this.btnCal3 = new System.Windows.Forms.Button();
            this.btnCal4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Location = new System.Drawing.Point(126, 26);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(101, 12);
            this.lblPosition.TabIndex = 0;
            this.lblPosition.Text = "좌표 생성 및 변경";
            // 
            // lblNow
            // 
            this.lblNow.AutoSize = true;
            this.lblNow.Location = new System.Drawing.Point(411, 26);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new System.Drawing.Size(85, 12);
            this.lblNow.TabIndex = 1;
            this.lblNow.Text = "현재 좌표 정보";
            // 
            // lblX1
            // 
            this.lblX1.AutoSize = true;
            this.lblX1.Location = new System.Drawing.Point(70, 61);
            this.lblX1.Name = "lblX1";
            this.lblX1.Size = new System.Drawing.Size(21, 12);
            this.lblX1.TabIndex = 2;
            this.lblX1.Text = "X :";
            // 
            // lblY1
            // 
            this.lblY1.AutoSize = true;
            this.lblY1.Location = new System.Drawing.Point(70, 100);
            this.lblY1.Name = "lblY1";
            this.lblY1.Size = new System.Drawing.Size(21, 12);
            this.lblY1.TabIndex = 3;
            this.lblY1.Text = "Y :";
            // 
            // lblZ1
            // 
            this.lblZ1.AutoSize = true;
            this.lblZ1.Location = new System.Drawing.Point(70, 135);
            this.lblZ1.Name = "lblZ1";
            this.lblZ1.Size = new System.Drawing.Size(21, 12);
            this.lblZ1.TabIndex = 4;
            this.lblZ1.Text = "Z :";
            // 
            // lblC1
            // 
            this.lblC1.AutoSize = true;
            this.lblC1.Location = new System.Drawing.Point(70, 171);
            this.lblC1.Name = "lblC1";
            this.lblC1.Size = new System.Drawing.Size(35, 12);
            this.lblC1.TabIndex = 5;
            this.lblC1.Text = "Color";
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(128, 58);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(100, 21);
            this.txtX1.TabIndex = 6;
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(128, 97);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(100, 21);
            this.txtY1.TabIndex = 7;
            // 
            // txtZ1
            // 
            this.txtZ1.Location = new System.Drawing.Point(128, 132);
            this.txtZ1.Name = "txtZ1";
            this.txtZ1.Size = new System.Drawing.Size(100, 21);
            this.txtZ1.TabIndex = 8;
            // 
            // txtC1
            // 
            this.txtC1.Location = new System.Drawing.Point(128, 168);
            this.txtC1.Name = "txtC1";
            this.txtC1.Size = new System.Drawing.Size(100, 21);
            this.txtC1.TabIndex = 9;
            // 
            // txtC2
            // 
            this.txtC2.Location = new System.Drawing.Point(413, 168);
            this.txtC2.Name = "txtC2";
            this.txtC2.Size = new System.Drawing.Size(100, 21);
            this.txtC2.TabIndex = 17;
            // 
            // txtZ2
            // 
            this.txtZ2.Location = new System.Drawing.Point(413, 132);
            this.txtZ2.Name = "txtZ2";
            this.txtZ2.Size = new System.Drawing.Size(100, 21);
            this.txtZ2.TabIndex = 16;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(413, 97);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(100, 21);
            this.txtY2.TabIndex = 15;
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(413, 58);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(100, 21);
            this.txtX2.TabIndex = 14;
            // 
            // lblC2
            // 
            this.lblC2.AutoSize = true;
            this.lblC2.Location = new System.Drawing.Point(355, 171);
            this.lblC2.Name = "lblC2";
            this.lblC2.Size = new System.Drawing.Size(35, 12);
            this.lblC2.TabIndex = 13;
            this.lblC2.Text = "Color";
            // 
            // lblZ2
            // 
            this.lblZ2.AutoSize = true;
            this.lblZ2.Location = new System.Drawing.Point(355, 135);
            this.lblZ2.Name = "lblZ2";
            this.lblZ2.Size = new System.Drawing.Size(21, 12);
            this.lblZ2.TabIndex = 12;
            this.lblZ2.Text = "Z :";
            // 
            // lblY2
            // 
            this.lblY2.AutoSize = true;
            this.lblY2.Location = new System.Drawing.Point(355, 100);
            this.lblY2.Name = "lblY2";
            this.lblY2.Size = new System.Drawing.Size(21, 12);
            this.lblY2.TabIndex = 11;
            this.lblY2.Text = "Y :";
            // 
            // lblX2
            // 
            this.lblX2.AutoSize = true;
            this.lblX2.Location = new System.Drawing.Point(355, 61);
            this.lblX2.Name = "lblX2";
            this.lblX2.Size = new System.Drawing.Size(21, 12);
            this.lblX2.TabIndex = 10;
            this.lblX2.Text = "X :";
            // 
            // btnCal1
            // 
            this.btnCal1.Location = new System.Drawing.Point(271, 55);
            this.btnCal1.Name = "btnCal1";
            this.btnCal1.Size = new System.Drawing.Size(35, 23);
            this.btnCal1.TabIndex = 18;
            this.btnCal1.Text = ">>";
            this.btnCal1.UseVisualStyleBackColor = true;
            this.btnCal1.Click += new System.EventHandler(this.btnCal1_Click);
            // 
            // btnMake
            // 
            this.btnMake.Location = new System.Drawing.Point(89, 230);
            this.btnMake.Name = "btnMake";
            this.btnMake.Size = new System.Drawing.Size(75, 23);
            this.btnMake.TabIndex = 22;
            this.btnMake.Text = "객체 생성";
            this.btnMake.UseVisualStyleBackColor = true;
            this.btnMake.Click += new System.EventHandler(this.btnMake_Click);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(207, 230);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(75, 23);
            this.btnChange.TabIndex = 23;
            this.btnChange.Text = "변경";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(318, 230);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(75, 23);
            this.btnMove.TabIndex = 24;
            this.btnMove.Text = "이동";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnCal2
            // 
            this.btnCal2.Location = new System.Drawing.Point(271, 94);
            this.btnCal2.Name = "btnCal2";
            this.btnCal2.Size = new System.Drawing.Size(35, 23);
            this.btnCal2.TabIndex = 25;
            this.btnCal2.Text = ">>";
            this.btnCal2.UseVisualStyleBackColor = true;
            this.btnCal2.Click += new System.EventHandler(this.btnCal2_Click);
            // 
            // btnCal3
            // 
            this.btnCal3.Location = new System.Drawing.Point(271, 130);
            this.btnCal3.Name = "btnCal3";
            this.btnCal3.Size = new System.Drawing.Size(35, 23);
            this.btnCal3.TabIndex = 26;
            this.btnCal3.Text = ">>";
            this.btnCal3.UseVisualStyleBackColor = true;
            this.btnCal3.Click += new System.EventHandler(this.btnCal3_Click);
            // 
            // btnCal4
            // 
            this.btnCal4.Location = new System.Drawing.Point(271, 165);
            this.btnCal4.Name = "btnCal4";
            this.btnCal4.Size = new System.Drawing.Size(35, 23);
            this.btnCal4.TabIndex = 27;
            this.btnCal4.Text = ">>";
            this.btnCal4.UseVisualStyleBackColor = true;
            this.btnCal4.Click += new System.EventHandler(this.btnCal4_Click);
            // 
            // ColorableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCal4);
            this.Controls.Add(this.btnCal3);
            this.Controls.Add(this.btnCal2);
            this.Controls.Add(this.btnMove);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.btnMake);
            this.Controls.Add(this.btnCal1);
            this.Controls.Add(this.txtC2);
            this.Controls.Add(this.txtZ2);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.lblC2);
            this.Controls.Add(this.lblZ2);
            this.Controls.Add(this.lblY2);
            this.Controls.Add(this.lblX2);
            this.Controls.Add(this.txtC1);
            this.Controls.Add(this.txtZ1);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.txtX1);
            this.Controls.Add(this.lblC1);
            this.Controls.Add(this.lblZ1);
            this.Controls.Add(this.lblY1);
            this.Controls.Add(this.lblX1);
            this.Controls.Add(this.lblNow);
            this.Controls.Add(this.lblPosition);
            this.Name = "ColorableForm";
            this.Text = "좌표이동";
            this.Load += new System.EventHandler(this.ColorableForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblNow;
        private System.Windows.Forms.Label lblX1;
        private System.Windows.Forms.Label lblY1;
        private System.Windows.Forms.Label lblZ1;
        private System.Windows.Forms.Label lblC1;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtZ1;
        private System.Windows.Forms.TextBox txtC1;
        private System.Windows.Forms.TextBox txtC2;
        private System.Windows.Forms.TextBox txtZ2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.Label lblC2;
        private System.Windows.Forms.Label lblZ2;
        private System.Windows.Forms.Label lblY2;
        private System.Windows.Forms.Label lblX2;
        private System.Windows.Forms.Button btnCal1;
        private System.Windows.Forms.Button btnMake;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnCal2;
        private System.Windows.Forms.Button btnCal3;
        private System.Windows.Forms.Button btnCal4;
    }
}

