﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ColorableProject
{
    public partial class ColorableForm : Form
    {
        Colorable3DPoint c3p = null;
        public ColorableForm()
        {
            InitializeComponent();
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            int x, y, z;
            string color;

            x = int.Parse(txtX1.Text);
            y = Convert.ToInt32(txtY1.Text);
            z = Convert.ToInt32(txtZ1.Text);
            color = txtC1.Text;

            c3p = new Colorable3DPoint(x, y, z, color);
            print3DPoint();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            int x, y, z;

            x = int.Parse(txtX1.Text);
            y = Convert.ToInt32(txtY1.Text);
            z = Convert.ToInt32(txtZ1.Text);

            c3p.MoveTo(x, y, z);
            print3DPoint();
        }
        private void print3DPoint()
        {
            txtX2.Text = Convert.ToString(c3p.GetX());
            txtY2.Text = Convert.ToString(c3p.GetY());
            txtZ2.Text = c3p.GetZ().ToString();
            txtC2.Text = c3p.GetColor();
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            int x, y, z;

            x = int.Parse(txtX1.Text);
            y = Convert.ToInt32(txtY1.Text);
            z = Convert.ToInt32(txtZ1.Text);

            c3p.MoveBy(x, y, z);
            print3DPoint();
        }

        private void btnCal1_Click(object sender, EventArgs e)
        {
            int x;
            x = int.Parse(txtX1.Text);
            c3p.SetX(x);
            print3DPoint();
        }

        private void btnCal2_Click(object sender, EventArgs e)
        {
            int y;
            y = int.Parse(txtY1.Text);
            c3p.SetY(y);
            print3DPoint();
        }

        private void btnCal3_Click(object sender, EventArgs e)
        {
            int z;
            z = int.Parse(txtZ1.Text);
            c3p.SetZ(z);
            print3DPoint();
        }

        private void btnCal4_Click(object sender, EventArgs e)
        {
            c3p.SetColor(txtC1.Text);
            print3DPoint();
        }

        private void ColorableForm_Load(object sender, EventArgs e)
        {

        }
    }
}
