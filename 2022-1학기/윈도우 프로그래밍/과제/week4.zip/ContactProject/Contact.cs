﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactProject
{
    internal class Contact//연락처를 저장할수 있는 클래스
    {
        string name;
        int age;
        string company;
        string cellPhone;
        string tel;
        string mail;

        public Contact(string name, int age, string company, string cellPhone, string tel, string mail)//모든 받은 값을 저장
        {
            this.name = name;
            this.age = age;
            this.company = company;
            this.cellPhone = cellPhone;
            this.tel = tel;
            this.mail = mail;
        }
        public override string ToString()//출력해주는 매서드
        {
            return "이름 : " + name + " 나이 : " + age + " 회사 : " + company + " 휴대폰 : " + cellPhone + " 전화 : " + tel + " 메일 : " + mail;
        }
    }
}
