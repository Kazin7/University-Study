﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactProject
{
    public partial class ContactForm : Form
    {
        Contact c = null;
        public ContactForm()
        {
            InitializeComponent();
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            c = new Contact(txtName.Text, int.Parse(txtAge.Text), txtCompany.Text, txtCell.Text, txtTel.Text, txtMail.Text);
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            txtPrint.Text = c.ToString();
        }
    }
}
