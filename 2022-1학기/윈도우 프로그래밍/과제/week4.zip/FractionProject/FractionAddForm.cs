﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FractionProject
{
    public partial class FractionAddForm : Form
    {
        public FractionAddForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            Fraction f1 = new Fraction(int.Parse(txtNumerator1.Text), int.Parse(txtDenominator1.Text));
            Fraction f2 = new Fraction(int.Parse(txtNumerator2.Text), int.Parse(txtDenominator2.Text));
            Fraction f3 = new Fraction(0,0);

            f3 = f3.combine(f1, f2);

            txtDenominator3.Text = f3.getDeno().ToString();
            txtNumerator3.Text = f3.getNum().ToString();
        }

        private void txtDenominator2_TextChanged(object sender, EventArgs e)
        {

        }

        private void FractionAddForm_Load(object sender, EventArgs e)
        {

        }
    }
    public class Fraction //분수의 분자 분모값을 가지고 있는 클래스
    {
        private int numerator;
        private int denominator;

        public Fraction(int numerator,int denominator)//생성자
        {
            this.numerator = numerator;
            this.denominator = denominator;
        }
        public int getNum()//각각 변수에 접근하기 위한 get set메서드
        {
            return numerator;
        }
        public int getDeno()
        {
            return denominator;
        }

        public void setNum(int numerator)
        {
            this.numerator = numerator;
        }
        public void setDeno(int denominator)
        {
            this.denominator = denominator;
        }
        public Fraction combine(Fraction f1,Fraction f2) //분수 두개를 합쳐 약분까지 하는 함수
        {
            Fraction f = new Fraction(0,0);
            int small;//분자 분모중 작은 값을 저장하기위해 선언

            if (f1.denominator == f2.denominator)//분모가 같을 경우
            {
                f.denominator = f1.denominator;
                f.numerator = f1.numerator + f2.numerator;
            }
            else//그 이외의 일반적인 경우
            {
                f.denominator = f1.denominator * f2.denominator; //일반적인 경우 처럼 분모*분자 + 분모*분자를 해준다
                f.numerator = (f1.numerator * f2.denominator) + (f2.numerator * f1.denominator);
            }
            
            if (f.numerator < f.denominator)//약분 해주는 부분
            {
                small = f.numerator;//작은값 설정
            }
            else
            {
                small = f.denominator;
            }
            for (int i = 2; i < small; i++)//for문을 돌면서 2이상의 수부터 나눠질경우에 약분해준다
            {
                if (f.numerator % i == 0 && f.denominator % i == 0)
                {
                    f.numerator = f.numerator / i;
                    f.denominator = f.denominator / i;
                }
            }
            return f;
        }
    }
}
