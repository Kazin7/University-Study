﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointExam
{
    internal class Point //포인트 클래스 생성
    {
        private int x;
        private int y;

        public Point(int x,int y)//생성자
        {
            this.x = x;
            this.y = y;
        }
        public void SetX(int x)//set get 매서드
        {
            this.x = x;
        }
        public void SetY(int y)
        {
            this.y = y;
        }
        public int GetX()
        {
            return x;
        }
        public int GetY()
        {
            return y;
        }
        public void MoveTo(int x,int y)//좌표 재설정 매서드
        {
            this.x = x;
            this.y = y;
        }
        public void MoveBy(int mx ,int my)//좌표 이동 매서드
        {
            this.x = this.x + mx;
            this.y = this.y + my; 
        }
        public override string ToString()//값 출력 매서드
        {
            return "x : " + this.x + ", y : " + this.y;
        }
    }
}
