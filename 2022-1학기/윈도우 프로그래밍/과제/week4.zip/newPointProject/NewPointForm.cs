﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newPointProject
{
    public partial class NewPointForm : Form
    {
        public NewPointForm()
        {
            InitializeComponent();
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            if (txtX.Text.Contains('.'))
            {
                Point<double> p;
                p = new Point<double>(double.Parse(txtX.Text), double.Parse(txtY.Text));
                txtObj.Text = p.ToString();
            }
            else
            {
                Point<int> p;
                p = new Point<int>(int.Parse(txtX.Text), int.Parse(txtY.Text));
                txtObj.Text = p.ToString();
            }

        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            
            if (txtX.Text.Contains('.'))
            {
                Point<double> p;
                p = new Point<double>(double.Parse(txtX.Text), double.Parse(txtY.Text));
                p.MoveTo(double.Parse(txtX.Text), double.Parse(txtY.Text));
                txtObj.Text = p.ToString();
            }
            else
            {
                Point<int> p;
                p = new Point<int>(int.Parse(txtX.Text), int.Parse(txtY.Text));
                p.MoveTo(int.Parse(txtX.Text), int.Parse(txtY.Text));
                txtObj.Text = p.ToString();
            }
        }

        private void NewPointForm_Load(object sender, EventArgs e)
        {

        }
    }
}
