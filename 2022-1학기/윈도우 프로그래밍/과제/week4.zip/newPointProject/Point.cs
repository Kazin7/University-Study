﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newPointProject
{
    public class Point<DataType>//범용클래스 선언
    {
        private DataType x;
        private DataType y;

        public Point(DataType x, DataType y)//생성자
        {
            this.x = x;
            this.y = y;
        }
        public DataType getX()
        {
            return x;
        }
        public DataType getY()
        {
            return y;
        }

        public void setX(DataType x)
        {
            this.x=x;
        }
        public void setY(DataType y)
        {
            this.y = y;
        }

        public void MoveTo(DataType x , DataType y)//좌표변경 메서드
        {
            this.x = x;
            this.y = y;
        }
        public override string ToString()//오버라이드 ToString 값출력 매서드
        {
            return "x : " + x + ", y : " + y;
        }
    }
}
