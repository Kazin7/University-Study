﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    internal class Book//책의 정보를 가지고있는 클래스
    {
        private string title;
        private string author;
        private int page;
        private string ISBN;
        private string publisher;

        public Book(string title, string author, int page, string ISBN, string publisher)//생성자로 값들 초기화
        {
            this.title = title;
            this.author = author;
            this.page = page;
            this.ISBN = ISBN;
            this.publisher = publisher;
        }
        public string Title//프로퍼티
        {
            get
            {
                return title;
            }
            set
            {
                this.title = value;
            }
        }
        public override string ToString()//책 정보 출력하는 메서드
        {
            return "책 제목 : " + title + "\r\n책 저자 : " + author + "\r\n쪽 수 : " + page + "\r\n국제표준도서번호 : " + ISBN + "\r\n출판사 : " + publisher;
        }

    }
}
