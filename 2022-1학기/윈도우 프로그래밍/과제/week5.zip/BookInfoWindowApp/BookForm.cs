﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookInfoWindowApp
{
    public partial class BookForm : Form
    {
        EBook eb = null;
        public BookForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            eb = new EBook(txtTitle.Text, txtAuthor.Text, int.Parse(txtPages.Text), txtISBN.Text, txtPublisher.Text, int.Parse(txtPrice.Text));

        }

        private void btnSale_Click(object sender, EventArgs e)
        {
            eb.DiscountPrice(int.Parse(txtDiscount.Text));
        }

        private void btnOfs_Click(object sender, EventArgs e)
        {
            if (eb.OutOfStock)
            {
                eb.StorageInWareHouse();
                txtResult.Text = "품절되었습니다.";
            }
            else
            {
                eb.StockOut();
                txtResult.Text = "입고되었습니다.";
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            txtResult.Text = eb.ToString();
        }
    }
}
