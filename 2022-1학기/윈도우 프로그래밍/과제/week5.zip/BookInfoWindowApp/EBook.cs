﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    internal class EBook : Book,Sale//Book클래스와 Sale인터페이스를 상속받는 클래스
    {
        private int price;//책 가격
        bool outOfStock = false;//품절인지 아닌지 체크하는 변수

        public EBook(string title, string author, int page, string ISBN, string publisher, int price)//생성자
            :base(title,author,page,ISBN,publisher)//상위 클래스를 이용해서 초기화
        {
            this.price = price;
        }
        public int Price//가격의 프로퍼티 설정
        {
            get { return price; }
            set { price = value; }
        }
        public bool OutOfStock//품절여부의 프로퍼티
        {
            get { return outOfStock; }
            set { outOfStock = value; }
        }
        public override string ToString()//기존 출력에 가격 추가
        {
            return base.ToString() + "\r\n가격 : " + price;
        }
        public void DiscountPrice(int discount)//가격을 할인해주는 함수
        {
            price = price - discount;
        }
        public void StockOut()//품절상태로 만듬
        {
            outOfStock = true;
        }
        public void StorageInWareHouse()//재고가 있는 상태로 만듬
        {
            OutOfStock = false;
        }

    }
}
