﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    internal interface Sale//인터페이스
    {
        void DiscountPrice(int discount);
        void StockOut();
        void StorageInWareHouse();
    }
}
