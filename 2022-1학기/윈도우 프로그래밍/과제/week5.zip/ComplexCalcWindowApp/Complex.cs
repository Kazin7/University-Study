﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplexCalcWindowApp
{
    internal class Complex//허수를 표현하는 클래스
    {
        double real;
        double imaginary;

        public Complex(double real, double imaginary)//생성자
        {
            this.real = real;
            this.imaginary = imaginary;
        }
        public double Real//프로퍼티
        {
            get { return real; }
            set { real = value; }
        }
        public double Imaginary//프로퍼티
        {
            get { return imaginary; }
            set { imaginary = value; }
        }
        public static Complex operator +(Complex c1, Complex c2)// + 연산자 재정의
        {
            Complex c = new Complex(0, 0);
            c.real = c1.real + c2.real;
            c.imaginary = c1.imaginary + c2.imaginary;
            return c;
        }
        public static Complex operator *(Complex c1, Complex c2)// * 연산자 재정의
        {
            Complex c = new Complex(0, 0);
            c.real = (c1.real * c2.real) - (c1.imaginary * c2.imaginary);
            c.imaginary = (c2.real * c1.imaginary) + (c2.real * c2.imaginary);
            return c;
        }
    }
}
