﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComplexCalcWindowApp
{
    public partial class ComplexForm : Form
    {
        Complex c1;
        Complex c2;
        public ComplexForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Complex c;
            c1 = new Complex(double.Parse(txtr1.Text), double.Parse(txti1.Text));
            c2 = new Complex(double.Parse(txtr2.Text), double.Parse(txti2.Text));
            c = c1 + c2; //연산자 재정의를 이용하여 값 더하기
            txtr3.Text = c.Real + "";
            txti3.Text = c.Imaginary + "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Complex c;
            c1 = new Complex(double.Parse(txtr1.Text), double.Parse(txti1.Text));
            c2 = new Complex(double.Parse(txtr2.Text), double.Parse(txti2.Text));
            c = c1 * c2;//연산자 재정의를 이용하여 값 곱하기
            txtr3.Text = c.Real + "";
            txti3.Text = c.Imaginary + "";
        }
    }
}
