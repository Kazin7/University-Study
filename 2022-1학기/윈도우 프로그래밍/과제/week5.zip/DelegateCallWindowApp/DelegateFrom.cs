﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DelegateCallWindowApp
{
    public partial class DelegateFrom : Form
    {
        public delegate void Calc(int value1, int value2);//델리게이트
        String s = ""; //txtResult에 모든 출력을 저장시킬 변수
        public DelegateFrom()
        {
            InitializeComponent();
        }

        private void add(int value1, int value2)//더하기
        {
            s += value1 + " + " + value2 + " = " + (value1 + value2) + Environment.NewLine;
        }
        private void minus(int value1, int value2)//빼기
        {
            s += value1 + " - " + value2 + " = " + (value1 - value2) + Environment.NewLine;
        }
        private void multi(int value1, int value2)//곱하기
        {
            s += value1 + " * " + value2 + " = " + (value1 * value2) + Environment.NewLine;
        }
        private void div(int value1, int value2)//나누기
        {
            s += value1 + " / " + value2 + " = " + (value1 / value2) + Environment.NewLine;
        }
        private void button3_Click(object sender, EventArgs e)//더하기 클릭
        {
            Calc cal = new Calc(add);
            cal(int.Parse(txtValue1.Text), int.Parse(txtValue2.Text));
        }
        private void button4_Click(object sender, EventArgs e)//빼기 클릭
        {
            Calc cal = new Calc(minus);
            cal(int.Parse(txtValue1.Text), int.Parse(txtValue2.Text));
        }

        private void button5_Click(object sender, EventArgs e)//곱하기 클릭
        {
            Calc cal = new Calc(multi);
            cal(int.Parse(txtValue1.Text), int.Parse(txtValue2.Text));
        }

        private void button6_Click(object sender, EventArgs e)//나누기 클릭
        {
            Calc cal = new Calc(div);
            cal(int.Parse(txtValue1.Text), int.Parse(txtValue2.Text));
        }

        private void button1_Click(object sender, EventArgs e)//Run클릭시 모두 출력
        {
            txtResult.Text = s;
        }

        private void button2_Click(object sender, EventArgs e)//Clear클릭시 모두 제거
        {
            txtResult.Text = "";//모든값 초기화
            s = "";
        }
    }
}
