﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointIndexerWindowApp
{
    public delegate void RunDel(int x, int y);//델리게이트 선언
    internal class Point
    {
        int x, y;
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public Point()
        {
            this.x = 0;
            this.y = 0;
        }
        public int X//프로퍼티
        {
            get { return this.x; }
            set { this.x = value; }
        }
        public int Y//프로퍼티
        {
            get { return this.y; }
            set { this.y = value; }
        }
        public void MoveTo(int x,int y)//좌표값을 변경하는 매서드
        {
            this.x = x;
            this.y = y;
        }
        public void MoveBy(int moveX, int moveY)//좌표 값을 이동하는 매서드
        {
            x = x + moveX;
            y = y + moveY;
        }
        public override string ToString()//값 출력
        {
            return "x : " + x + ", y : " + y +"\r\n"; 
        }
        public static Point operator+ ( Point p1, Point p2)//연산자 재정의
        {
            return new Point(p1.X +p2.X, p1.Y+p2.Y);
        }
        public static Point operator- (Point p1, Point p2)
        {
            return new Point(p1.X - p2.X, p1.Y - p2.Y);
        }
        
    }
}
