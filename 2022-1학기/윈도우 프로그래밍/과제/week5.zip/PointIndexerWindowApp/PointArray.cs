﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointIndexerWindowApp
{
    internal class PointArray
    {
        Point[] points = new Point[10];//포인터 배열
        public static int count = 0;//정적변수 선언

        public Point this[int index]//포인터 인덱서
        {
            get
            {
                return points[index];
            }
            set
            {
                points[index] = value;
            }
        }

    }
}
