﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PointIndexerWindowApp
{
    public partial class PointForm : Form
    {
        PointArray pa = new PointArray();
        
        public PointForm()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            pa[PointArray.count] = new Point(int.Parse(txtX.Text), int.Parse(txtY.Text));//객체 생성
            PointArray.count++;//정적변수 값 1증가
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s = "";
            for(int i = 0; i < PointArray.count; i++)//저장되어있는 모든 객체값 불러오기
            {
                s+=pa[i].ToString();
            }
            txtResult.Text = s;//text에 저장
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < PointArray.count; i++)//객체 배열에 있는 모든 값 변경
            {
                RunDel rd = new RunDel(pa[i].MoveTo);
                rd(int.Parse(txtX.Text), int.Parse(txtY.Text));
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < PointArray.count; i++)//객체 배열에 있는 모든 값 이동
            {
                RunDel rd = new RunDel(pa[i].MoveBy);
                rd(int.Parse(txtX.Text), int.Parse(txtY.Text));
            }
        }
    }
}
