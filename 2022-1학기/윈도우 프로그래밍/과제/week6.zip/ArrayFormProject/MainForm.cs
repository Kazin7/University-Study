﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArrayFormProject
{
    public partial class MainForm : Form
    {
        int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnPrint_Click(object sender, EventArgs e)//특정한 배열의 인덱스 값을 출력
        {
            txtResult.Text = "";//초기화
            try
            {
                int index = int.Parse(txtIndex.Text);
                txtResult.Text = this.arr[index] + "";
            }
            catch(FormatException fe)//입력형식 예외처리
            {
                txtResult.Text = fe.Message;
            }
            catch(IndexOutOfRangeException ioore)//배열 인덱스 범위 예외처리
            {
                txtResult.Text = ioore.Message;
            }
            
        }

        private void btnPrintAll_Click(object sender, EventArgs e)//모든 배열값 출력
        {
            txtResult.Text = "";//초기화
            for (int i = 0; i < arr.Length; i++)//배열의 길이만큼 반복
            {
                if(i == arr.Length-1)//마지막 원소일경우
                {
                    txtResult.Text += arr[i] + "";//,를 제거
                }
                else
                {
                    txtResult.Text += arr[i] + ",";
                }
                
                
            }
            
        }
    }
}
