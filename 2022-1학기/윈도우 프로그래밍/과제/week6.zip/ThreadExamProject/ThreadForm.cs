﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ThreadExamProject
{
    public partial class ThreadForm : Form
    {
        Thread t1, t2;//전역변수 선언
        public ThreadForm()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)//출력 클릭시
        {
            ThreadStart ts1 = new ThreadStart(print_increase);//스레드 두개생성
            ThreadStart ts2 = new ThreadStart(print_decrease);

            t1 = new Thread(ts1);
            t2 = new Thread(ts2);

            t1.Start();//스레드 두개 시작
            t2.Start();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            t1.Suspend();//멈춤 클릭시 스레드 두개 중지
            t2.Suspend();
        }
        private void print_increase()//증가시키는 매서드
        {
            int i = 0;
            while (true)//무한 반복
            {
                txtPrintView1.Text += i + Environment.NewLine;
                i++;
                Thread.Sleep(1000);//1초간격으로 출력
            }
        }

        private void ThreadForm_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void print_decrease()//감소 시키는 매서드
        {
            int i = 100000;
            while (true)//무한 반복
            {
                txtPrintView2.Text += i + Environment.NewLine;
                i--;
                Thread.Sleep(1000);//1초간격으로 출력
            }
        }
    }
}
