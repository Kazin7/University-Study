﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormEventProject
{
    public partial class EventForm : Form
    {
        public EventForm()
        {
            InitializeComponent();
        }

        private void EventForm_Load(object sender, EventArgs e) //처음 실행될경우
        {
            string formInfo = "Form Size : 넓이 = " + this.Size.Width + ", 높이 = " + this.Size.Height; //사이즈 출력
            MessageBox.Show(formInfo);//메시지 띄우기
        }

        private void EventForm_MouseMove(object sender, MouseEventArgs e)//마우스가 움직일경우
        {
            lblOut.Text = "마우스위치: x =" + e.X + ", y = " + e.Y;//텍스트에 마우스의 위치표시
        }

        private void EventForm_MouseClick(object sender, MouseEventArgs e)//마우스 클릭시
        {
            MessageBox.Show(e.Button.ToString());//클릭된 마우스 버튼을 띄우기
        }

        private void EventForm_KeyPress(object sender, KeyPressEventArgs e)//키보드가 눌렸을 시
        {
            MessageBox.Show(e.KeyChar.ToString());//메시지 띄우기
        }

        private void EventForm_KeyDown(object sender, KeyEventArgs e)//특수키가 눌렸을 시
        {
            MessageBox.Show(e.KeyCode.ToString());//메시지 띄우기
        }
    }
}
