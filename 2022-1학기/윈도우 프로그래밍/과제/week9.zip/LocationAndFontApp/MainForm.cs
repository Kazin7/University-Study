﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocationAndFontApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnUp_Click(object sender, EventArgs e)//크게 버튼 클릭시
        {
            lblHorse.Font = new Font("궁서",lblHorse.Font.Size + 1);//폰트를 바꾸고 크기를 1증가
        }

        private void btnDown_Click(object sender, EventArgs e)//작게 버튼 클릭시
        {
            lblHorse.Font = new Font("궁서", lblHorse.Font.Size - 1);//폰트를 바꾸고 크기를 1감소
        }

        private void btnOrigin_Click(object sender, EventArgs e)//처음위치 클릭시
        {
            lblHorse.Location = new Point(330, 90);//초기위치로 이동
        }


        //버튼 클릭에 따른 말의 이동 좌표 설정
        private void btnU_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X , lblHorse.Location.Y-1) ;

        }

        private void btnLU_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X-1, lblHorse.Location.Y-1);
        }

        private void btnRU_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X+1, lblHorse.Location.Y-1);
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X-1, lblHorse.Location.Y);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X+1, lblHorse.Location.Y);
        }

        private void btnLD_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X-1, lblHorse.Location.Y+1);
        }

        private void btnD_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X, lblHorse.Location.Y+1);
        }

        private void btnRD_Click(object sender, EventArgs e)
        {
            lblHorse.Location = new Point(lblHorse.Location.X+1, lblHorse.Location.Y+1);
        }
    }
}
