﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotePadApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            MessageBox.Show("NotePad V 0,1");
        }

        private void btnExit_Click(object sender, EventArgs e)//종료버튼 클릭시
        {
            this.Close();//종료
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)//창이 닫힐경우 이벤트
        {
            if(txtMemo.Text != "")//내용이 비어있지 않다면
            {
                if( MessageBox.Show("변경 내용을 버리고 종료하시겠습니까?", "종료확인", MessageBoxButtons.YesNo) == DialogResult.Yes)//메세지 출력후 yes클릭시
                {
                    e.Cancel = false;//창닫기 취소
                }
                else
                {
                    e.Cancel=true;//종료
                }
            }
        }
    }
}
