import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


f = open('bit-coin.csv','r')
coindesk_data = pd.read_csv(f,header=0)
seq = coindesk_data[['종가']].to_numpy()
print('데이터 길이:',len(seq),'\n앞쪽 5개 값:',seq[0:5])


plt.plot(seq,color='red')
plt.title('Bitcoin Prices (1 year from 2019-02-28)')
plt.xlabel('Days'); plt.ylabel('Price in USD')
plt.show()